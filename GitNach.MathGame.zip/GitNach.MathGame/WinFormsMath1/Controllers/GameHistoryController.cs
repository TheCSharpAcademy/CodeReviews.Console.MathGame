﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WinFormsMath1.Model;

namespace WinFormsMath1.Controllers
{
    public static class GameHistoryController
    {
        public static List<GameHistory> History { get; set; } = new();
        
    }
}
