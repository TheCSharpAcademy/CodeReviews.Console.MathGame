using System.Collections;

public class MathGameLogic
{
    
}